package com.example.megacitycab;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField txtUsername;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private void handleLogin() {
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        // Validate credentials (use a mock or database check here)
        if ("admin".equals(username) && "password".equals(password)) {
            try {
                MainApp.loadDashboard();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            // Show an error message or alert
        }
    }
}
